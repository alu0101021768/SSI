# Vernam Cipher
* The cipher operates bit to bit , by applying a XOR operation between the original message and the random key.
* The decypher operates bit to bit , by applying a XOR operation between the encrypted message and the random key.
